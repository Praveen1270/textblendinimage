import React, { useState, useRef, ChangeEvent, useEffect } from 'react';
import { HexColorPicker } from 'react-colorful';
import { Upload, Image as ImageIcon, Type, Palette, Download, Move, Maximize2, BringToFront, Search, Loader2, Eraser, Copy, Trash2, ArrowRight, ArrowDown, Wand2 } from 'lucide-react';
import { createWorker } from 'tesseract.js';
import WebFont from 'webfontloader';

const FONTS = [
  'Roboto', 'Arial', 'Times New Roman', 'Georgia', 'Verdana',
  'Helvetica', 'Courier New', 'Trebuchet MS', 'Impact', 'Comic Sans MS',
  'Palatino', 'Garamond', 'Bookman', 'Avant Garde', 'Helvetica Neue',
  'Futura', 'Century Gothic', 'Calibri', 'Candara', 'Franklin Gothic',
  'Optima', 'Baskerville', 'Cambria', 'Constantia', 'Corbel',
  'Didot', 'Geneva', 'Goudy Old Style', 'Hoefler Text', 'Lucida Grande',
  'Monaco', 'Perpetua', 'Rockwell', 'Segoe UI', 'Tahoma',
  'Arial Black', 'Copperplate', 'Gill Sans', 'Lucida Sans', 'Myriad Pro',
  'Palatino Linotype', 'Symbol', 'Times', 'Univers', 'Westminster',
  'Arial Narrow', 'Book Antiqua', 'Lucida Console', 'MS Sans Serif', 'Wide Latin'
];

const BLEND_MODES = [
  'normal', 'multiply', 'screen', 'overlay', 'darken', 
  'lighten', 'color-dodge', 'color-burn', 'hard-light', 
  'soft-light', 'difference', 'exclusion'
];

interface TextConfig {
  id: string;
  content: string;
  color: string;
  fontSize: number;
  x: number;
  y: number;
  width: number;
  height: number;
  opacity: number;
  rotation: number;
  letterSpacing: number;
  font: string;
  horizontalTilt: number;
  verticalTilt: number;
  blendMode: string;
}

function App() {
  const [image, setImage] = useState<string | null>(null);
  const [texts, setTexts] = useState<TextConfig[]>([]);
  const [selectedTextId, setSelectedTextId] = useState<string | null>(null);
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const previewRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    WebFont.load({
      google: {
        families: FONTS
      }
    });
  }, []);

  const createNewText = () => {
    const newText: TextConfig = {
      id: Date.now().toString(),
      content: 'Your Text',
      color: '#ffffff',
      fontSize: 120,
      x: previewRef.current ? previewRef.current.clientWidth / 2 - 100 : 0,
      y: previewRef.current ? previewRef.current.clientHeight / 2 - 50 : 0,
      width: 200,
      height: 100,
      opacity: 1,
      rotation: 0,
      letterSpacing: 0,
      font: 'Arial',
      horizontalTilt: 0,
      verticalTilt: 0,
      blendMode: 'overlay'
    };
    setTexts([...texts, newText]);
    setSelectedTextId(newText.id);
  };

  const duplicateText = (textId: string) => {
    const textToDuplicate = texts.find(t => t.id === textId);
    if (textToDuplicate) {
      const newText = {
        ...textToDuplicate,
        id: Date.now().toString(),
        x: textToDuplicate.x + 20,
        y: textToDuplicate.y + 20
      };
      setTexts([...texts, newText]);
      setSelectedTextId(newText.id);
    }
  };

  const removeText = (textId: string) => {
    setTexts(texts.filter(t => t.id !== textId));
    if (selectedTextId === textId) {
      setSelectedTextId(null);
    }
  };

  const updateText = (textId: string, updates: Partial<TextConfig>) => {
    setTexts(texts.map(t => t.id === textId ? { ...t, ...updates } : t));
  };

  const handleImageUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setImage(event.target?.result as string);
        if (texts.length === 0) {
          createNewText();
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleMouseDown = (e: React.MouseEvent, textId: string) => {
    if (!previewRef.current) return;
    const rect = previewRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const text = texts.find(t => t.id === textId);
    if (text) {
      setSelectedTextId(textId);
      setIsDragging(true);
      setDragStart({ x: x - text.x, y: y - text.y });
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || !previewRef.current || !selectedTextId) return;
    const rect = previewRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    updateText(selectedTextId, {
      x: x - dragStart.x,
      y: y - dragStart.y
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleDownload = () => {
    if (canvasRef.current && image) {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const img = new Image();
      img.onload = () => {
        canvas.width = img.width;
        canvas.height = img.height;
        
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0);
        
        texts.forEach(text => {
          const scaleX = img.width / (previewRef.current?.clientWidth || 1);
          const scaleY = img.height / (previewRef.current?.clientHeight || 1);
          const scaledX = text.x * scaleX;
          const scaledY = text.y * scaleY;
          const scaledFontSize = text.fontSize * Math.min(scaleX, scaleY);
          
          ctx.save();
          
          ctx.translate(scaledX, scaledY);
          ctx.rotate(text.rotation * Math.PI / 180);
          ctx.transform(1, Math.tan(text.verticalTilt * Math.PI / 180), 
                       Math.tan(text.horizontalTilt * Math.PI / 180), 1, 0, 0);
          
          ctx.font = `${scaledFontSize}px ${text.font}`;
          ctx.fillStyle = text.color;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.letterSpacing = `${text.letterSpacing}px`;
          ctx.globalAlpha = text.opacity;
          ctx.globalCompositeOperation = text.blendMode as GlobalCompositeOperation;
          
          const letters = text.content.split('');
          let currentX = 0;
          
          letters.forEach(letter => {
            ctx.fillText(letter, currentX, 0);
            const metrics = ctx.measureText(letter);
            currentX += metrics.width + text.letterSpacing;
          });
          
          ctx.restore();
        });

        const link = document.createElement('a');
        link.download = 'text-behind-image.png';
        link.href = canvas.toDataURL('image/png');
        link.click();
      };
      img.src = image;
    }
  };

  const selectedText = texts.find(t => t.id === selectedTextId);

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Text Behind Object Creator</h1>
          <p className="text-gray-600">Create stunning text-behind-object designs with AI-powered tools</p>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Preview Area */}
            <div 
              ref={previewRef}
              className="relative min-h-[400px] bg-gray-200 rounded-lg overflow-hidden"
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseUp}
            >
              {image ? (
                <>
                  {texts.map(text => (
                    <div 
                      key={text.id}
                      className={`absolute cursor-move select-none ${selectedTextId === text.id ? 'ring-2 ring-blue-500' : ''}`}
                      style={{
                        left: `${text.x}px`,
                        top: `${text.y}px`,
                        fontSize: `${text.fontSize}px`,
                        color: text.color,
                        opacity: text.opacity,
                        transform: `
                          rotate(${text.rotation}deg)
                          skew(${text.horizontalTilt}deg, ${text.verticalTilt}deg)
                        `,
                        letterSpacing: `${text.letterSpacing}px`,
                        fontFamily: text.font,
                        mixBlendMode: text.blendMode as any
                      }}
                      onMouseDown={(e) => handleMouseDown(e, text.id)}
                    >
                      {text.content}
                    </div>
                  ))}
                  <img 
                    src={image} 
                    alt="Preview" 
                    className="w-full h-full object-cover"
                  />
                </>
              ) : (
                <div className="text-center p-8">
                  <ImageIcon className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                  <p className="text-gray-500">Upload an image to get started</p>
                </div>
              )}
            </div>

            {/* Controls */}
            <div className="space-y-6">
              {/* Upload */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Upload Image
                </label>
                <label className="flex items-center justify-center w-full h-12 px-4 transition bg-white border-2 border-gray-300 border-dashed rounded-md appearance-none cursor-pointer hover:border-gray-400 focus:outline-none">
                  <span className="flex items-center space-x-2">
                    <Upload className="w-5 h-5 text-gray-400" />
                    <span className="text-sm text-gray-600">Choose a file</span>
                  </span>
                  <input type="file" className="hidden" onChange={handleImageUpload} accept="image/*" />
                </label>
              </div>

              {/* Text Management */}
              <div className="flex space-x-2">
                <button
                  onClick={() => createNewText()}
                  className="flex-1 flex items-center justify-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
                >
                  <Type className="w-5 h-5 mr-2" />
                  Add Text
                </button>
                {selectedText && (
                  <>
                    <button
                      onClick={() => duplicateText(selectedText.id)}
                      className="flex-1 flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                    >
                      <Copy className="w-5 h-5 mr-2" />
                      Duplicate
                    </button>
                    <button
                      onClick={() => removeText(selectedText.id)}
                      className="flex-1 flex items-center justify-center px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
                    >
                      <Trash2 className="w-5 h-5 mr-2" />
                      Remove
                    </button>
                  </>
                )}
              </div>

              {selectedText && (
                <>
                  {/* Text Input */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      <Type className="w-4 h-4 inline mr-2" />
                      Text Content
                    </label>
                    <input
                      type="text"
                      value={selectedText.content}
                      onChange={(e) => updateText(selectedText.id, { content: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  {/* Font Selection */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Font Family
                    </label>
                    <select
                      value={selectedText.font}
                      onChange={(e) => updateText(selectedText.id, { font: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      {FONTS.map(font => (
                        <option key={font} value={font} style={{ fontFamily: font }}>
                          {font}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Blend Mode */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      <Wand2 className="w-4 h-4 inline mr-2" />
                      Blend Mode
                    </label>
                    <select
                      value={selectedText.blendMode}
                      onChange={(e) => updateText(selectedText.id, { blendMode: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      {BLEND_MODES.map(mode => (
                        <option key={mode} value={mode}>
                          {mode.charAt(0).toUpperCase() + mode.slice(1)}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Font Size */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      <Maximize2 className="w-4 h-4 inline mr-2" />
                      Font Size
                    </label>
                    <input
                      type="range"
                      min="20"
                      max="400"
                      value={selectedText.fontSize}
                      onChange={(e) => updateText(selectedText.id, { fontSize: Number(e.target.value) })}
                      className="w-full"
                    />
                  </div>

                  {/* Letter Spacing */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Letter Spacing
                    </label>
                    <input
                      type="range"
                      min="-10"
                      max="50"
                      value={selectedText.letterSpacing}
                      onChange={(e) => updateText(selectedText.id, { letterSpacing: Number(e.target.value) })}
                      className="w-full"
                    />
                  </div>

                  {/* Rotation */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Rotation
                    </label>
                    <input
                      type="range"
                      min="-180"
                      max="180"
                      value={selectedText.rotation}
                      onChange={(e) => updateText(selectedText.id, { rotation: Number(e.target.value) })}
                      className="w-full"
                    />
                  </div>

                  {/* Horizontal Tilt */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      <ArrowRight className="w-4 h-4 inline mr-2" />
                      Horizontal Tilt
                    </label>
                    <input
                      type="range"
                      min="-45"
                      max="45"
                      value={selectedText.horizontalTilt}
                      onChange={(e) => updateText(selectedText.id, { horizontalTilt: Number(e.target.value) })}
                      className="w-full"
                    />
                  </div>

                  {/* Vertical Tilt */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      <ArrowDown className="w-4 h-4 inline mr-2" />
                      Vertical Tilt
                    </label>
                    <input
                      type="range"
                      min="-45"
                      max="45"
                      value={selectedText.verticalTilt}
                      onChange={(e) => updateText(selectedText.id, { verticalTilt: Number(e.target.value) })}
                      className="w-full"
                    />
                  </div>

                  {/* Opacity Control */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      <Eraser className="w-4 h-4 inline mr-2" />
                      Opacity
                    </label>
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.1"
                      value={selectedText.opacity}
                      onChange={(e) => updateText(selectedText.id, { opacity: Number(e.target.value) })}
                      className="w-full"
                    />
                  </div>

                  {/* Color Picker */}
                  <div className="relative">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      <Palette className="w-4 h-4 inline mr-2" />
                      Text Color
                    </label>
                    <button
                      onClick={() => setShowColorPicker(!showColorPicker)}
                      className="w-full h-10 rounded-md border border-gray-300"
                      style={{ backgroundColor: selectedText.color }}
                    />
                    {showColorPicker && (
                      <div className="absolute z-10 mt-2">
                        <HexColorPicker
                          color={selectedText.color}
                          onChange={(color) => updateText(selectedText.id, { color })}
                        />
                      </div>
                    )}
                  </div>
                </>
              )}

              {/* Download Button */}
              <button
                onClick={handleDownload}
                disabled={!image}
                className="w-full flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed"
              >
                <Download className="w-5 h-5 mr-2" />
                Download Image
              </button>
            </div>
          </div>
        </div>

        {/* Hidden canvas for image processing */}
        <canvas ref={canvasRef} className="hidden" />
      </div>
    </div>
  );
}

export default App;